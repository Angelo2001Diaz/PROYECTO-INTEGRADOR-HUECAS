var clientes = [
    { cedula: '0915637628', nombre: 'MARJORIE', apellido: 'ALCIVAR', email: 'alcivar_marjorie@hotmail.com', 
    edad: '41', ciudad: 'MILAGRO', telefono: '0961197042' },
    { cedula: '0923280171', nombre: 'GLENDA', apellido: 'ALVARADO', email: 'alvarado_glenda@gmail.com', 
    edad: '42', ciudad: 'GUAYAQUIL', telefono: '0989692896'},
    { cedula: '0905625252', nombre: 'NORMA', apellido: 'ANGULO', email: 'angulo_norma@yahoo.es', 
    edad: '34', ciudad: 'GUAYAQUIL', telefono: '0982862955'},
    { cedula: '0908701357', nombre: 'MARITZA', apellido: 'ARECHUA', email: 'arechua_maritza@hotmail.com', 
    edad: '43', ciudad: 'GUAYAQUIL', telefono: '0992134217'},
    { cedula: '1302886521', nombre: 'LUCIA', apellido: 'ARTEAGA', email: 'arteaga_lucia@gmail.com', 
    edad: '36', ciudad: 'GUAYAQUIL', telefono: '0997487931'},
    { cedula: '0916122737', nombre: 'KARY', apellido: 'ARTEAGA', email: 'arteaga_kary@yahoo.es',
    edad: '34', ciudad: 'QUEVEDO', telefono: '0986379168'},
    { cedula: '0923114586', nombre: 'VICTOR', apellido: 'AVILES', email: 'aviles_victor@hotmail.com',
    edad: '38', ciudad: 'CUENCA', telefono: '0967058925'},
    { cedula: '0919177902', nombre: 'PATRICIA', apellido: 'BALLADARES', email: 'balladares_patricia@gmail.com',
    edad: '31', ciudad: 'QUITO', telefono: '0982916447'},
    { cedula: '1307761489', nombre: 'JESUS', apellido: 'BAQUE', email: 'baque_jesus@yahoo.es',
    edad: '41', ciudad: 'GUAYAQUIL', telefono: '0991780628'}
];


function modificar(cedula, cliente) {
    const indice = clientes.findIndex(elementos => elementos.cedula == cedula);
    if (indice > -1) {
        clientes[indice] = cliente;
    }else{
        alert('No se encontró el Cliente');
    }
    guardarStorage();
    
}

function guardar(cliente){
    clientes.push(cliente);
    guardarStorage();
}

function eliminar(cedula){
    const indice = clientes.findIndex(elementos => elementos.cedula == cedula);
    if (indice > -1) {
        clientes.splice(indice, 1);
    }else{
        alert('No se encontró el Cliente');
    }
    guardarStorage();
}


function guardarStorage() {
    localStorage.setItem('clientes', JSON.stringify(clientes));
}

function recuperarUsuarios() {
    clientes = JSON.parse(localStorage.getItem('clientes'));
}

recuperarUsuarios();

